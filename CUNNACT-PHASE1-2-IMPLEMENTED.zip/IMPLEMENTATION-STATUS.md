# CUNNACT implementation status — 23 Sep 2026

## Completed in this pass

### Foundation / stability
- Strengthened first-load chat handling by merging an un-ordered Firestore fallback slice for small/legacy conversations whose records may omit `createdAt`.
- Kept the existing timeout + retry path and realtime listener cleanup.

### Messaging foundation
- Message edit flow with a 15-minute client/rules guard.
- Forward one or multiple selected messages to another existing conversation.
- Per-user message pin/unpin (`pinnedBy`).
- Message details modal.
- Multi-select mode with bulk delete-for-me and save/forward actions.
- In-conversation search over currently loaded history.
- Emoji insertion palette.
- Built-in lightweight sticker palette.
- Voice-note recording using MediaRecorder and a generic Cloudinary upload helper.
- Rendering support for audio/video/document/sticker message records created by the new message model.

## Existing and preserved
- Google/email authentication + verification
- Message requests
- Direct chat / groups
- Reactions
- Save / delete / reply
- Presence + typing + delivery/read state
- Cloudinary image upload
- Desktop New Chat -> Create group
- Mobile New group option

## Requires external/live setup or later phases
- Cloudinary unsigned preset must permit `auto` uploads before audio/video/document uploads can work live.
- GIF search provider/API integration is not yet added; GIF files can already be selected through the existing image picker.
- Calls, stories, communities, channels, global discovery, advanced privacy/security, AI, multi-device/device management, backup, and final security/performance audit remain later phases.

## Validation
- `node --check` passes for all JS files.
- `index.html` currently has no duplicate element IDs.

## Request Flow Follow-up

- [x] Outgoing pending-request listener
- [x] Cancel pending request from New Chat search
- [x] Prevent accidental full overwrite of existing request records
- [x] Firestore sender-only pending delete rule
- [x] More actionable permission/network error handling
- [x] Legacy/public-profile account compatibility in `canContact`


# Phase 1–2 implementation (this round)

Implemented in the current web build:
- Message editing, soft-delete-for-everyone, delete-for-me, reply, forward, reactions, pin, save/bookmark, details, multi-select and in-chat search.
- Emoji/sticker UI plus GIF URL sending (GIPHY/Tenor direct GIF URLs).
- Voice-note recording/upload flow.
- Multiple image/video/document selection with per-file status, aggregate progress, retry of failed uploads, 8-file batch limit and 50 MB aggregate batch limit.
- Image quality selector: optimized / HD / original.
- Album metadata for multi-file sends.
- Video/document rendering, contact sharing, location sharing and secure lightweight URL previews.
- Cloudinary media validation and multi-resource upload helper.
- Firestore rule support for sender soft-delete.

External setup still required for production media breadth: the unsigned Cloudinary upload preset must allow the resource types being used (images/video/raw/auto as appropriate). Browser geolocation, microphone and later native permissions remain platform-dependent.
